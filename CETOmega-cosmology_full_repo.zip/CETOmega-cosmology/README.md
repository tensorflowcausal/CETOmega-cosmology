# CETOmega–cosmology (multisonda)

Repositorio de ejemplo para validar el marco CET Ω con varias sondas:

- BAO radiales (DESI DR2 u otros)
- Supernovas tipo Ia (Pantheon+/Union)
- Prior comprimido de CMB (theta_*)

## Estructura

- `src/ceto_model.py` — modelo de expansión CET Ω (H(z), distancias).
- `src/likelihood_bao.py` — verosimilitud BAO D_H(z)/r_d.
- `src/likelihood_sne.py` — verosimilitud SNe Ia (módulo de distancia).
- `src/likelihood_cmb.py` — prior comprimido CMB (theta_*).
- `src/run_mcmc.py` — MCMC conjunto BAO+SNe+CMB con emcee.
- `src/make_corner.py` — figura tipo corner de la cadena.
- `src/make_figures.py` — figuras H(z), BAO vs datos, etc.

Los datos de ejemplo se encuentran en `data/`. Puedes reemplazarlos por
tus catálogos reales manteniendo el mismo formato de columnas.

## Uso rápido

```bash
pip install -r requirements.txt
python -m src.run_mcmc
python -m src.make_corner
python -m src.make_figures
```

Esto generará:

- `chains.npy` — cadena plana del MCMC.
- `figures/corner_multiprobe.png`
- `figures/H_of_z.png`
- `figures/DH_over_rd_vs_DESI.png`
