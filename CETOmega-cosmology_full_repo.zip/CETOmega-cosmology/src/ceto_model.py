import numpy as np
from scipy.integrate import quad


class CETOmegaModel:
    """
    Minimal CET Omega cosmological model scaffold.

    Esta clase implementa H(z) y distancias en un modelo efectivo
    muy sencillo. La idea es que reemplaces E_of_z() y sound_horizon()
    por tu formulación completa CET Ω. El resto del pipeline (likelihoods
    y MCMC) no necesita cambios.
    """

    c = 299792.458  # velocidad de la luz en km/s

    def __init__(self, H0: float = 70.0):
        self.H0 = H0

    # ------------------------------------------------------------------
    #  Manejo de parámetros
    # ------------------------------------------------------------------
    def _parse_params(self, params):
        """
        Acepta diccionario o array y devuelve (Omega_m, alpha0, alpha1).
        """
        if isinstance(params, dict):
            om = params.get("Omega_m", 0.3)
            a0 = params.get("alpha0", 1.5)
            a1 = params.get("alpha1", 0.8)
        else:
            om, a0, a1 = params
        return om, a0, a1

    # ------------------------------------------------------------------
    #  H(z)
    # ------------------------------------------------------------------
    def E_of_z(self, z, params):
        """
        H(z)/H0 para CET Ω (versión toy).

        IMPORTANTE: reemplazar esto por tu expresión real de CET Ω.
        Aquí usamos algo tipo dark-energy efectiva:
            E^2(z) = Ω_m (1+z)^3 + a0 + a1 (1+z)

        con parámetros (Omega_m, a0, a1).
        """
        om, a0, a1 = self._parse_params(params)
        z = np.asarray(z, dtype=float)
        zp1 = 1.0 + z
        E2 = om * zp1**3 + a0 + a1 * zp1
        # Evitar raíces negativas
        if np.any(E2 <= 0.0):
            return np.inf * np.ones_like(z)
        return np.sqrt(E2)

    def H_of_z(self, z, params):
        """H(z) en km/s/Mpc."""
        return self.H0 * self.E_of_z(z, params)

    # ------------------------------------------------------------------
    #  Distancias (vectorizadas y compatibles con quad)
    # ------------------------------------------------------------------
    def DH_of_z(self, z, params):
        """
        D_H(z) = c / H(z) en Mpc.

        Acepta escalar o array.
        """
        return self.c / self.H_of_z(z, params)

    def DC_of_z(self, z, params):
        """
        D_C(z) = ∫_0^z c / H(z') dz' en Mpc.

        Acepta escalar o array y hace la integral elemento a elemento.
        """
        z_arr = np.atleast_1d(z)

        def integrand(zp):
            return self.c / self.H_of_z(zp, params)

        vals = []
        for zi in z_arr:
            val, _ = quad(integrand, 0.0, float(zi))
            vals.append(val)

        vals = np.array(vals)
        if np.isscalar(z):
            return float(vals[0])
        return vals

    def DM_of_z(self, z, params):
        """D_M(z) en universo plano: D_M = D_C."""
        return self.DC_of_z(z, params)

    def DL_of_z(self, z, params):
        """Distancia de luminosidad D_L(z) en Mpc."""
        z_arr = np.atleast_1d(z)
        dm = self.DM_of_z(z_arr, params)
        dl = (1.0 + z_arr) * dm
        if np.isscalar(z):
            return float(dl[0])
        return dl

    def DA_of_z(self, z, params):
        """Distancia angular D_A(z) en Mpc."""
        z_arr = np.atleast_1d(z)
        dm = self.DM_of_z(z_arr, params)
        da = dm / (1.0 + z_arr)
        if np.isscalar(z):
            return float(da[0])
        return da

    # ------------------------------------------------------------------
    #  Horizonte acústico (placeholder)
    # ------------------------------------------------------------------
    def sound_horizon(self, params):
        """
        Placeholder para r_s; reemplazar por la física temprana de CET Ω.

        Por ahora devuelve un valor fijo en Mpc.
        """
        return 147.0
