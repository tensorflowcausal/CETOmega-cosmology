import numpy as np


def load_bao_table(filename):
    """
    Lee una tabla BAO tipo DESI/BOSS con columnas:

        z   D_H_over_rdrag   sigma_D_H_over_rdrag

    Puedes adaptar los índices a tu formato real.
    """
    data = np.genfromtxt(filename, comments="#")
    z = data[:, 0]
    y = data[:, 1]
    sigma = data[:, 2]
    return z, y, sigma


def loglike_bao(params, model, z, y_obs, sigma_y):
    """
    Likelihood gaussiana para BAO radiales D_H(z)/r_d.
    """
    rs = model.sound_horizon(params)  # r_d efectivo
    DH = model.DH_of_z(z, params)
    y_th = DH / rs
    chi2 = np.sum((y_obs - y_th)**2 / sigma_y**2)
    return -0.5 * chi2
