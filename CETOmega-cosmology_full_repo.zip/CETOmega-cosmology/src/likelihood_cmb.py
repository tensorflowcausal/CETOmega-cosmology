import numpy as np


def loglike_cmb(params, model):
    """
    Prior comprimido CMB en términos de theta_* ~ r_s / D_A(z_*).

    Aquí usamos un valor efectivo tipo Planck+ACT. Si quieres leerlo desde
    archivo, puedes modificar esta función para cargar theta_star y sigma.
    """
    # Datos efectivos (puedes reemplazar por tus números)
    theta_star_data = 0.01041
    sigma_theta = 0.00014
    z_star = 1090.0

    rs = model.sound_horizon(params)
    DA = model.DA_of_z(z_star, params)
    theta_model = rs / DA

    chi2 = (theta_star_data - theta_model)**2 / sigma_theta**2
    return -0.5 * chi2
