import numpy as np


def load_pantheon_like(filename):
    """
    Lee un archivo de SNe tipo Pantheon/Union con columnas:

        z   mu   sigma_mu
    """
    data = np.genfromtxt(filename, comments="#")
    z = data[:, 0]
    mu = data[:, 1]
    sigma = data[:, 2]
    return z, mu, sigma


def distance_modulus(DL_Mpc):
    """
    DL en Mpc -> módulo de distancia mu.
    mu = 5 log10(DL / 10 pc)
       = 5 log10(DL[Mpc]) + 25
    """
    return 5.0 * np.log10(DL_Mpc) + 25.0


def loglike_sne(params, model, z, mu_obs, sigma_mu):
    """
    Likelihood gaussiana para SNe Ia.
    """
    DL = model.DL_of_z(z, params)
    mu_th = distance_modulus(DL)
    chi2 = np.sum((mu_obs - mu_th)**2 / sigma_mu**2)
    return -0.5 * chi2
