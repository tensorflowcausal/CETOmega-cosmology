import numpy as np
import matplotlib.pyplot as plt
import corner


def main(chain_file="chains.npy", out_file="figures/corner_multiprobe.png"):
    chain = np.load(chain_file)
    labels = [r"$\Omega_m$", r"$\alpha_0$", r"$\alpha_1$"]
    fig = corner.corner(chain, labels=labels, show_titles=True)
    fig.savefig(out_file, bbox_inches="tight")
    print(f"Saved corner plot to {out_file}")


if __name__ == "__main__":
    main()
