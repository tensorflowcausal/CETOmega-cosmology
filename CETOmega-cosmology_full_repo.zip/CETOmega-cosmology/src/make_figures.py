import numpy as np
import matplotlib.pyplot as plt

from .ceto_model import CETOmegaModel
from .likelihood_bao import load_bao_table
from .likelihood_sne import load_pantheon_like


def plot_H_of_z(params, out_file="figures/H_of_z.png"):
    model = CETOmegaModel(H0=70.0)
    z = np.linspace(0.0, 2.0, 200)
    H = model.H_of_z(z, params)

    plt.figure()
    plt.plot(z, H)
    plt.xlabel(r"$z$")
    plt.ylabel(r"$H(z)$ [km s$^{-1}$ Mpc$^{-1}$]")
    plt.title("CETΩ H(z)")
    plt.grid(True, alpha=0.3)
    plt.savefig(out_file, bbox_inches="tight")
    plt.close()
    print(f"Saved {out_file}")


def plot_BAO(params, data_file="data/desi_dr2_bao.txt",
             out_file="figures/DH_over_rd_vs_DESI.png"):
    model = CETOmegaModel(H0=70.0)
    z, y_obs, sigma = load_bao_table(data_file)
    rs = model.sound_horizon(params)
    DH = model.DH_of_z(z, params)
    y_th = DH / rs

    plt.figure()
    plt.errorbar(z, y_obs, yerr=sigma, fmt="o", label="BAO data")
    plt.plot(z, y_th, "-", label="CETΩ best fit")
    plt.xlabel(r"$z$")
    plt.ylabel(r"$D_H(z)/r_d$")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.savefig(out_file, bbox_inches="tight")
    plt.close()
    print(f"Saved {out_file}")


def main():
    # Cargar cadena y usar la media como mejor ajuste
    chain = np.load("chains.npy")
    theta_best = np.mean(chain, axis=0)

    plot_H_of_z(theta_best)
    plot_BAO(theta_best)


if __name__ == "__main__":
    main()
