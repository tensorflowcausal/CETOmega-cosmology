import numpy as np
import emcee

from .ceto_model import CETOmegaModel
from .likelihood_bao import load_bao_table, loglike_bao
from .likelihood_sne import load_pantheon_like, loglike_sne
from .likelihood_cmb import loglike_cmb

model = CETOmegaModel(H0=70.0)

# Datos (puedes sustituir por tus ficheros reales)
z_bao, y_bao, sigma_bao = load_bao_table("data/desi_dr2_bao.txt")
z_sne, mu_sne, sigma_sne = load_pantheon_like("data/union30_sne.txt")


def logprior(theta):
    """
    theta = (Omega_m, alpha0, alpha1)
    Priors uniformes amplios pero razonables.
    """
    Omega_m, alpha0, alpha1 = theta
    if 0.01 < Omega_m < 0.6 and -5.0 < alpha0 < 5.0 and -5.0 < alpha1 < 5.0:
        return 0.0
    return -np.inf


def loglike(theta):
    """
    Likelihood conjunto BAO + SNe + CMB.
    """
    params = {"Omega_m": theta[0], "alpha0": theta[1], "alpha1": theta[2]}

    ll_bao = loglike_bao(params, model, z_bao, y_bao, sigma_bao)
    ll_sne = loglike_sne(params, model, z_sne, mu_sne, sigma_sne)
    ll_cmb = loglike_cmb(params, model)

    return ll_bao + ll_sne + ll_cmb


def logprob(theta):
    lp = logprior(theta)
    if not np.isfinite(lp):
        return -np.inf
    ll = loglike(theta)
    if not np.isfinite(ll):
        return -np.inf
    return lp + ll


def run_chains(nwalkers=32, nsteps=2000, out_file="chains.npy"):
    ndim = 3
    rng = np.random.default_rng()

    # Condiciones iniciales alrededor de un guess razonable
    p0_mean = np.array([0.3, 1.5, 0.8])
    p0_sigma = np.array([0.05, 0.2, 0.2])
    p0 = rng.normal(p0_mean, p0_sigma, size=(nwalkers, ndim))

    sampler = emcee.EnsembleSampler(nwalkers, ndim, logprob)

    print("Running MCMC...")
    sampler.run_mcmc(p0, nsteps, progress=True)

    chain = sampler.get_chain(discard=nsteps // 2, flat=True)
    np.save(out_file, chain)
    print(f"Saved chain to {out_file}")

    return sampler


if __name__ == "__main__":
    run_chains()
