# CET Ω Empirical Validation

This repository implements a background-level empirical validation of a CET Ω–type
cosmological model against late-time data:

- Galaxy BAO measurements (DV/r_d, DM/r_d, DH/r_d) from Aubourg et al. 2015.
- A small subset of *H(z)* measurements from cosmic chronometers.
- Planck 2018–like CMB distance priors (R, l_A, z_*).

The core expansion history is defined by

- Radiation + matter + an effective CET Ω sector encoded in D_Ω(z),
- A physical sound horizon r_s(z) using the photon–baryon sound speed,
- A drag scale r_d = r_s(z_d).

The code is written in plain NumPy/SciPy/Matplotlib and is organized so that
you can easily extend it with more data (Pantheon SNe, DESI BAO, full H(z)
compilations, etc.).

## Installation

```bash
python -m venv .venv
source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Quick usage

Run a basic validation at a ΛCDM-like point (all CET Ω deformation
parameters set to zero):

```bash
python -m cetomega_validation.run_validation
```

This will:

- Compute the BAO, H(z), and CMB distance-prior χ² for the fiducial parameters.
- Produce simple figures in `figures/`:
  - `bao_DV_over_rd.png`
  - `bao_DM_DH_over_rd.png`
  - `Hz_chronometers.png`

You can then scan or fit the CET Ω parameters by modifying `run_validation.py`
or by importing `cetomega_validation.model` and `cetomega_validation.likelihoods`
from your own scripts or notebooks.

## Disclaimer

- The data files shipped here are **small, reference subsets** of real datasets
  taken from the published literature (BAO summary tables, cosmic chronometer
  compilations, Planck distance priors). They are sufficient to test that the
  pipeline is numerically consistent and to perform proof-of-concept parameter
  studies.
- For full, state-of-the-art constraints you should replace/augment the CSV
  files in `data/` with the latest official releases (DESI, full Pantheon(+),
  updated H(z) compilations, etc.).

