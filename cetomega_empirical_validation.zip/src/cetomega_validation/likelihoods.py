"""
Likelihoods for BAO, H(z) cosmic chronometers, and CMB distance priors.

All likelihoods are intentionally kept simple and transparent:
- Diagonal Gaussian errors (no covariance matrices here).
- Observables defined directly in terms of the model functions.

You can replace or extend the CSV files in `data/` to include more
measurements or full covariance information if desired.
"""

import csv
import numpy as np

from .model import (
    DV, DM, DA, DH, r_d, H_cetomega, comoving_distance, r_s, c_light,
)


# ----------------------------------------
# BAO
# ----------------------------------------

def bao_theory(z, obs_type,
               H0, Omega_m, Omega_b, h,
               a0, a1, a_log, gamma, xi,
               z_d):
    """Return the BAO observable of a given type at redshift z.

    Supported types:
      - 'DV_over_rd'
      - 'DM_over_rd'
      - 'DA_over_rd'
      - 'DH_over_rd'
      - 'Hz_rd_over_c'
    """
    rd = r_d(H0, Omega_m, Omega_b, h,
             a0, a1, a_log, gamma, xi,
             z_d)

    if obs_type == "DV_over_rd":
        return DV(z, H0, Omega_m, a0, a1, a_log, gamma, xi) / rd

    if obs_type == "DM_over_rd":
        return DM(z, H0, Omega_m, a0, a1, a_log, gamma, xi) / rd

    if obs_type == "DA_over_rd":
        return DA(z, H0, Omega_m, a0, a1, a_log, gamma, xi) / rd

    if obs_type == "DH_over_rd":
        return DH(z, H0, Omega_m, a0, a1, a_log, gamma, xi) / rd

    if obs_type == "Hz_rd_over_c":
        Hz = H_cetomega(z, H0, Omega_m, a0, a1, a_log, gamma, xi)
        return Hz * rd / c_light

    raise ValueError(f"Unknown BAO observable type: {obs_type}")


def chi2_bao(path_csv,
             H0, Omega_m, Omega_b, h,
             a0, a1, a_log, gamma, xi,
             z_d):
    """BAO chi^2 from a CSV with columns: z,obs,sigma,type."""
    chi2 = 0.0
    with open(path_csv, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            z_str = row.get("z", "").strip()
            if not z_str or z_str.startswith("#"):
                continue

            z = float(z_str)
            obs = float(row["obs"])
            sigma = float(row["sigma"])
            obs_type = row["type"].strip()

            th = bao_theory(
                z, obs_type,
                H0, Omega_m, Omega_b, h,
                a0, a1, a_log, gamma, xi,
                z_d,
            )

            chi2 += ((obs - th) / sigma) ** 2

    return chi2


# ----------------------------------------
# H(z) cosmic chronometers
# ----------------------------------------

def chi2_hz(path_csv,
            H0, Omega_m,
            a0, a1, a_log, gamma, xi):
    """Chi^2 for H(z) chronometer data.

    CSV with columns: z, H, sigma
    where H and sigma are in km/s/Mpc.
    """
    chi2 = 0.0
    with open(path_csv, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            z_str = row.get("z", "").strip()
            if not z_str or z_str.startswith("#"):
                continue

            z = float(z_str)
            H_obs = float(row["H"])
            sigma = float(row["sigma"])

            H_th = H_cetomega(z, H0, Omega_m, a0, a1, a_log, gamma, xi)
            chi2 += ((H_obs - H_th) / sigma) ** 2

    return chi2


# ----------------------------------------
# CMB distance priors (R, l_A, z_star)
# ----------------------------------------

def cmb_theory(cmb_zstar,
               H0, Omega_m, Omega_b, h,
               a0, a1, a_log, gamma, xi):
    """Compute (R, l_A, z_star) for CMB distance priors.

    Here z_star is taken as an external input (e.g. fixed to the
    Planck best-fit value used in the priors table).
    """
    z_star = cmb_zstar

    Dm = DM(z_star, H0, Omega_m, a0, a1, a_log, gamma, xi)  # Mpc
    rs_zstar = r_s(z_star, H0, Omega_m, Omega_b, h,
                   a0, a1, a_log, gamma, xi)

    R = np.sqrt(Omega_m) * H0 * Dm / c_light
    lA = np.pi * Dm / rs_zstar

    return R, lA, z_star


def chi2_cmb(path_csv,
             cmb_zstar,
             H0, Omega_m, Omega_b, h,
             a0, a1, a_log, gamma, xi):
    """CMB distance prior chi^2.

    CSV columns: param,mean,sigma
    with param in {R, lA, zstar}.
    """
    R_th, lA_th, zstar_th = cmb_theory(
        cmb_zstar,
        H0, Omega_m, Omega_b, h,
        a0, a1, a_log, gamma, xi,
    )

    mapping = {
        "R": R_th,
        "lA": lA_th,
        "zstar": zstar_th,
    }

    chi2 = 0.0
    with open(path_csv, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["param"].strip()
            if name not in mapping:
                continue

            mean = float(row["mean"])
            sigma = float(row["sigma"])
            th = mapping[name]

            chi2 += ((mean - th) / sigma) ** 2

    return chi2


# ----------------------------------------
# Combined likelihood
# ----------------------------------------

def chi2_total(
    H0, Omega_m, Omega_b, h,
    a0, a1, a_log, gamma, xi,
    path_bao="data/bao_aubourg2015_subset.csv",
    path_hz="data/hz_chronometers_subset.csv",
    path_cmb="data/cmb_planck2018_distance_priors.csv",
    z_d=1059.0,
    cmb_zstar=1089.92,
    use_bao=True,
    use_hz=True,
    use_cmb=True,
):
    """Total chi^2 from BAO + H(z) + CMB (any subset can be toggled)."""
    chi2 = 0.0

    if use_bao:
        chi2 += chi2_bao(path_bao,
                         H0, Omega_m, Omega_b, h,
                         a0, a1, a_log, gamma, xi,
                         z_d)

    if use_hz:
        chi2 += chi2_hz(path_hz,
                        H0, Omega_m,
                        a0, a1, a_log, gamma, xi)

    if use_cmb:
        chi2 += chi2_cmb(path_cmb,
                        cmb_zstar,
                        H0, Omega_m, Omega_b, h,
                        a0, a1, a_log, gamma, xi)

    return chi2
