"""
Core cosmological background for CET Ω validation.

This follows exactly the structure you specified:

- D_Omega(z; a0, a1, a_log, gamma, xi)
- E_cetomega(z) including radiation, matter, and CET Ω sector
- H_cetomega(z) = H0 * E(z)
- Photon–baryon sound speed c_s(z)
- Sound horizon r_s(z) and drag scale r_d
- Distances DM, DA, DH, DV suitable for BAO analysis

All functions are written with explicit arguments instead of classes, to keep
the code transparent and easy to audit.
"""

import numpy as np
from scipy.integrate import quad

# ----------------------------------------
# Physical constants
# ----------------------------------------

c_light = 299792.458  # km/s
T_cmb   = 2.7255      # K

# For late-time BAO and H(z) (z <~ 3), the precise value of Ω_r has very small
# impact; we nevertheless include photons + massless neutrinos explicitly.
Omega_gamma_h2 = 2.47e-5
h_ref = 0.7
Omega_gamma = Omega_gamma_h2 / h_ref**2
N_eff = 3.046
Omega_r = Omega_gamma * (1.0 + 0.2271 * N_eff)


# ----------------------------------------
# 1) DΩ(z)
# ----------------------------------------

def D_Omega(z, a0, a1, a_log, gamma, xi):
    """CET Ω deformation D_Ω(z).

    Parameters
    ----------
    z : float or array
        Redshift.
    a0, a1, a_log, gamma, xi : floats
        Deformation parameters.

    Returns
    -------
    ndarray or float
        Value of D_Ω(z).
    """
    z = np.asarray(z)
    return (
        1.0
        + a0 * z / (1.0 + z)
        + a1 * (z**2) / (1.0 + z)**2
        + a_log * np.log(1.0 + z)
        + gamma * z
        + xi * z**2
    )


# ----------------------------------------
# 2) E(z) = H(z)/H0
# ----------------------------------------

def E_cetomega(z, Omega_m, a0, a1, a_log, gamma, xi):
    """Dimensionless Hubble rate E(z) = H(z)/H0 in CET Ω."""
    z = np.asarray(z)
    D = D_Omega(z, a0, a1, a_log, gamma, xi)
    Ez2 = (
        Omega_r * (1.0 + z)**4
        + Omega_m * (1.0 + z)**3
        + (1.0 - Omega_m - Omega_r) * D
    )
    return np.sqrt(Ez2)


# ----------------------------------------
# 3) H(z)
# ----------------------------------------

def H_cetomega(z, H0, Omega_m, a0, a1, a_log, gamma, xi):
    """Hubble rate in km/s/Mpc."""
    return H0 * E_cetomega(z, Omega_m, a0, a1, a_log, gamma, xi)


# ----------------------------------------
# 4) Photon–baryon sound speed
# ----------------------------------------

def R_b(z, Omega_b, h):
    """Baryon-loading parameter R(z) = 3 Ω_b / [4 Ω_γ (1+z)]."""
    Omega_gamma = Omega_gamma_h2 / h**2
    return 3.0 * Omega_b / (4.0 * Omega_gamma * (1.0 + z))


def c_s(z, Omega_b, h):
    """Sound speed in the photon–baryon fluid (km/s)."""
    return c_light / np.sqrt(3.0 * (1.0 + R_b(z, Omega_b, h)))


# ----------------------------------------
# 5) Sound horizon r_s(z)
# ----------------------------------------

def _r_s_integrand(z, H0, Omega_m, Omega_b, h,
                   a0, a1, a_log, gamma, xi):
    return c_s(z, Omega_b, h) / H_cetomega(z, H0, Omega_m,
                                           a0, a1, a_log, gamma, xi)


def r_s(z, H0, Omega_m, Omega_b, h,
        a0, a1, a_log, gamma, xi):
    """Comoving sound horizon r_s(z) in Mpc."""
    val, _ = quad(
        lambda zp: _r_s_integrand(zp, H0, Omega_m, Omega_b, h,
                                  a0, a1, a_log, gamma, xi),
        z, 1e6,  # large upper limit for convergence
        epsabs=0, epsrel=1e-5,
    )
    return val


# ----------------------------------------
# 6) Drag epoch r_d
# ----------------------------------------

def r_d(H0, Omega_m, Omega_b, h,
        a0, a1, a_log, gamma, xi,
        z_d):
    """Drag scale r_d = r_s(z_d) in Mpc."""
    return r_s(z_d, H0, Omega_m, Omega_b, h,
               a0, a1, a_log, gamma, xi)


# ----------------------------------------
# 7) Distances: D_C, D_M, D_A, D_H, D_V
# ----------------------------------------

def comoving_distance(z, H0, Omega_m,
                      a0, a1, a_log, gamma, xi):
    """Line-of-sight comoving distance D_C(z) in Mpc (flat case)."""
    integrand = lambda zp: 1.0 / E_cetomega(zp, Omega_m,
                                            a0, a1, a_log, gamma, xi)
    val, _ = quad(integrand, 0.0, z, epsabs=0, epsrel=1e-6)
    return (c_light / H0) * val


def DM(z, H0, Omega_m, a0, a1, a_log, gamma, xi):
    """Transverse comoving distance D_M(z) = D_C(z) for k=0."""
    return comoving_distance(z, H0, Omega_m, a0, a1, a_log, gamma, xi)


def DA(z, H0, Omega_m, a0, a1, a_log, gamma, xi):
    """Angular diameter distance D_A(z) = D_M(z)/(1+z)."""
    return DM(z, H0, Omega_m, a0, a1, a_log, gamma, xi) / (1.0 + z)


def DH(z, H0, Omega_m, a0, a1, a_log, gamma, xi):
    """Hubble distance D_H(z) = c / H(z)."""
    Hz = H_cetomega(z, H0, Omega_m, a0, a1, a_log, gamma, xi)
    return c_light / Hz


def DV(z, H0, Omega_m, a0, a1, a_log, gamma, xi):
    """Volume-averaged distance

        D_V(z) = [ z D_M(z)^2 D_H(z) ]^{1/3}.
    """
    Dm = DM(z, H0, Omega_m, a0, a1, a_log, gamma, xi)
    Dh = DH(z, H0, Omega_m, a0, a1, a_log, gamma, xi)
    return (z * Dm**2 * Dh) ** (1.0 / 3.0)
