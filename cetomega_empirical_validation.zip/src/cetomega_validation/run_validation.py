"""
Run a basic empirical validation of the CET Ω background model.

This script:
- Loads BAO, H(z), and CMB priors from `data/`.
- Evaluates chi^2 at a fiducial ΛCDM-like point (CET Ω deformation = 0).
- Produces simple comparison figures in `figures/`.

You can modify the parameters at the bottom to explore CET Ω deformations.
"""

import os
import numpy as np
import matplotlib.pyplot as plt

from .model import (
    DV, DM, DH, H_cetomega, r_d,
)
from .likelihoods import (
    chi2_bao, chi2_hz, chi2_cmb, chi2_total,
)


DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "..", "data")
FIG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "..", "figures")


def load_bao(path):
    import csv
    zs, obs, sigma, types = [], [], [], []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            z_str = row.get("z", "").strip()
            if not z_str or z_str.startswith("#"):
                continue
            zs.append(float(z_str))
            obs.append(float(row["obs"]))
            sigma.append(float(row["sigma"]))
            types.append(row["type"].strip())
    return np.array(zs), np.array(obs), np.array(sigma), np.array(types)


def load_hz(path):
    import csv
    zs, H, sigma = [], [], []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            z_str = row.get("z", "").strip()
            if not z_str or z_str.startswith("#"):
                continue
            zs.append(float(z_str))
            H.append(float(row["H"]))
            sigma.append(float(row["sigma"]))
    return np.array(zs), np.array(H), np.array(sigma)


def main():
    # Fiducial ΛCDM-like parameters (Planck-ish for demonstration)
    H0      = 67.4
    h       = H0 / 100.0
    Omega_m = 0.315
    Omega_b = 0.049

    # CET Ω deformation turned off for the baseline:
    a0 = a1 = a_log = gamma = xi = 0.0

    z_d = 1059.0
    cmb_zstar = 1089.92

    path_bao = os.path.join(DATA_DIR, "bao_aubourg2015_subset.csv")
    path_hz  = os.path.join(DATA_DIR, "hz_chronometers_subset.csv")
    path_cmb = os.path.join(DATA_DIR, "cmb_planck2018_distance_priors.csv")

    chi2_b = chi2_bao(path_bao,
                      H0, Omega_m, Omega_b, h,
                      a0, a1, a_log, gamma, xi,
                      z_d)

    chi2_h = chi2_hz(path_hz,
                     H0, Omega_m,
                     a0, a1, a_log, gamma, xi)

    chi2_c = chi2_cmb(path_cmb,
                      cmb_zstar,
                      H0, Omega_m, Omega_b, h,
                      a0, a1, a_log, gamma, xi)

    chi2_tot = chi2_b + chi2_h + chi2_c

    print("=== CET Ω empirical validation (baseline ΛCDM-like point) ===")
    print(f"H0      = {H0} km/s/Mpc")
    print(f"Omega_m = {Omega_m}")
    print(f"Omega_b = {Omega_b}")
    print(f"a0,a1,a_log,gamma,xi = {a0}, {a1}, {a_log}, {gamma}, {xi}")
    print()
    print(f"chi2_BAO = {chi2_b:.3f}")
    print(f"chi2_Hz  = {chi2_h:.3f}")
    print(f"chi2_CMB = {chi2_c:.3f}")
    print(f"chi2_tot = {chi2_tot:.3f}")

    # --- Figures ---

    os.makedirs(FIG_DIR, exist_ok=True)

    # 1) BAO DV/rd
    import csv
    zs, obs, sigma, types = load_bao(path_bao)

    # compute model values
    rd_val = r_d(H0, Omega_m, Omega_b, h,
                 a0, a1, a_log, gamma, xi,
                 z_d)

    mask_DV = types == "DV_over_rd"
    if np.any(mask_DV):
        z_plot = zs[mask_DV]
        DV_model = np.array([
            DV(z, H0, Omega_m, a0, a1, a_log, gamma, xi) / rd_val
            for z in z_plot
        ])

        plt.figure()
        plt.errorbar(z_plot, obs[mask_DV], yerr=sigma[mask_DV], fmt="o", label="BAO data (DV/rd)")
        plt.plot(z_plot, DV_model, "-", label="CET Ω (baseline)")
        plt.xlabel("z")
        plt.ylabel("D_V(z) / r_d")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(FIG_DIR, "bao_DV_over_rd.png"))
        plt.close()

    # 2) BAO DM/rd and DH/rd
    mask_DM = types == "DM_over_rd"
    mask_DH = types == "DH_over_rd"
    if np.any(mask_DM) or np.any(mask_DH):
        plt.figure()
        if np.any(mask_DM):
            z_DM = zs[mask_DM]
            DM_model = np.array([
                DM(z, H0, Omega_m, a0, a1, a_log, gamma, xi) / rd_val
                for z in z_DM
            ])
            plt.errorbar(z_DM, obs[mask_DM], yerr=sigma[mask_DM], fmt="o", label="BAO data (DM/rd)")
            plt.plot(z_DM, DM_model, "-", label="CET Ω DM/rd")

        if np.any(mask_DH):
            z_DH = zs[mask_DH]
            DH_model = np.array([
                DH(z, H0, Omega_m, a0, a1, a_log, gamma, xi) / rd_val
                for z in z_DH
            ])
            plt.errorbar(z_DH, obs[mask_DH], yerr=sigma[mask_DH], fmt="s", label="BAO data (DH/rd)")
            plt.plot(z_DH, DH_model, "--", label="CET Ω DH/rd")

        plt.xlabel("z")
        plt.ylabel("Distance / r_d")
        plt.legend()
        plt.tight_layout()
        plt.savefig(os.path.join(FIG_DIR, "bao_DM_DH_over_rd.png"))
        plt.close()

    # 3) H(z) chronometers
    hz_z, hz_H, hz_sigma = load_hz(path_hz)
    Hz_model = np.array([
        H_cetomega(z, H0, Omega_m, a0, a1, a_log, gamma, xi)
        for z in hz_z
    ])

    plt.figure()
    plt.errorbar(hz_z, hz_H, yerr=hz_sigma, fmt="o", label="Cosmic chronometers")
    plt.plot(hz_z, Hz_model, "-", label="CET Ω (baseline)")
    plt.xlabel("z")
    plt.ylabel("H(z) [km/s/Mpc]")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, "Hz_chronometers.png"))
    plt.close()


if __name__ == "__main__":
    main()
