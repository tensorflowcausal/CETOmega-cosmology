import numpy as np
from cetomega_validation.model import E_cetomega, D_Omega

def test_D_Omega_at_z0():
    # At z=0, D_Omega should be 1 for any parameters
    val = D_Omega(0.0, 0.1, -0.2, 0.3, -0.4, 0.5)
    assert np.isclose(val, 1.0)

def test_E_cetomega_positive():
    z = np.linspace(0, 5, 10)
    Ez = E_cetomega(z, Omega_m=0.3,
                    a0=0.0, a1=0.0, a_log=0.0, gamma=0.0, xi=0.0)
    assert np.all(Ez > 0)
